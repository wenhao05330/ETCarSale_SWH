CREATE VIEW V_NAME AS select name from school
/
