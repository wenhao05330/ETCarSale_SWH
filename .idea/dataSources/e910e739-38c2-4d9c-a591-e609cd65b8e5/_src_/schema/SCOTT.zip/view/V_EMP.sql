CREATE VIEW V_EMP AS select empno eno,ename ena,to_char(hiredate,'yyyy') eyear,sal esal from EMP where sal > 200 and job = 'CLERK' order by sal
/
