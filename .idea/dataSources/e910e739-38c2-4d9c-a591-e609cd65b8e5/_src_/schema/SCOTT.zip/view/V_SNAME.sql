CREATE VIEW V_SNAME AS select student.name stuname,school.name schname from student join school on student.sid = school.id
/
