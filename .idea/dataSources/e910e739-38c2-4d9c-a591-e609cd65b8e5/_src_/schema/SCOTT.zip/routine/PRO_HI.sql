CREATE procedure pro_hi(cr in number,cc out varchar)
as
begin
if cr = 1 then cc:= '你好';
else if cr = 2 then cc:='再见';
end if;
end if;
end;
/
