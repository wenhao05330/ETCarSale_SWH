CREATE procedure pro_test(
cr in number,
cc out varchar
)
as
begin
if cr = 1 then cc:='你好';
elsif cr = 2 then cc:='再见';
end if;
end;
/
